using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Collections.Generic;

public class ChatLogger : MonoBehaviour
{
    public static ChatLogger Instance { get; private set; }

    [Header("�`���b�gUI�̐e�I�u�W�F�N�g")]
    [SerializeField] private GameObject chatUIRoot;  // �� N�L�[�ŕ\���ؑւ�����UI

    [SerializeField] private Transform contentParent;
    [SerializeField] private GameObject chatItemPrefab;
    [SerializeField] private ScrollRect scrollRect;
    [SerializeField] private int maxMessages = 100;

    private readonly Queue<GameObject> messageQueue = new();
    private readonly Dictionary<string, GameObject> taggedMessages = new(); // GameObject�ɕύX�I

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.N) && chatUIRoot != null)
        {
            chatUIRoot.SetActive(!chatUIRoot.activeSelf);
        }
    }

    public void Log(string message, string tag = null)
    {
        // ���łɃ^�O�t�����b�Z�[�W������ꍇ�͍폜���čĒǉ�
        if (!string.IsNullOrEmpty(tag) && taggedMessages.TryGetValue(tag, out GameObject oldObj))
        {
            if (messageQueue.Contains(oldObj)) messageQueue.Enqueue(null); // �ʒu����΍�

            Destroy(oldObj);
            messageQueue.Dequeue(); // 1�폜�i�����ێ��j
            taggedMessages.Remove(tag);
        }

        // �V�������b�Z�[�W�𐶐�
        GameObject newMessage = Instantiate(chatItemPrefab, contentParent);
        TMP_Text text = newMessage.GetComponent<TMP_Text>();
        text.text = message;

        if (!string.IsNullOrEmpty(tag))
        {
            taggedMessages[tag] = newMessage;
        }

        messageQueue.Enqueue(newMessage);

        if (messageQueue.Count > maxMessages)
        {
            GameObject oldMessage = messageQueue.Dequeue();
            Destroy(oldMessage);
        }

        Canvas.ForceUpdateCanvases();
        scrollRect.verticalNormalizedPosition = 0f;
    }
}
