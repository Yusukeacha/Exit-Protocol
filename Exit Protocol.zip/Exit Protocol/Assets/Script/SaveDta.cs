using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class SaveData
{
    public int runeCount;
    public int stoneCount;
    public bool hasKey;
    public bool hasOpenedChest;
    public bool hasOpenedRuneChest;
    public bool goddessUsed;
    public bool pillarFixed;

    public int runePotIndex;
    public bool runePotCollected;

    public Vector3 playerPosition;
    public List<string> destroyedObjectIDs = new();
}
