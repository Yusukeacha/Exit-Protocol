using System.Collections.Generic;
using UnityEngine;

public class DestroyedObjectTracker : MonoBehaviour
{
    public static DestroyedObjectTracker Instance;
    private HashSet<string> destroyedIDs = new();

    private void Awake()
    {
        if (Instance != null) Destroy(gameObject);
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    public void MarkDestroyed(string id) => destroyedIDs.Add(id);
    public List<string> GetDestroyedObjectIDs() => new(destroyedIDs);
    public void LoadFrom(List<string> ids) => destroyedIDs = new HashSet<string>(ids);
    public bool IsDestroyed(string id) => destroyedIDs.Contains(id);
}
