﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class PropsAltar : MonoBehaviour
{
    public SpriteRenderer[] runeRenderers;
    public float colorChangeSpeed = 2.0f;
    public string gameClearSceneName = "GameClearScene"; // ← シーン名に合わせて修正

    private float targetAlpha = 0f;
    private bool isActivated = false;
    private bool gameCleared = false;

    private void Start()
    {
        // ルーンの透明度を初期化
        foreach (var renderer in runeRenderers)
        {
            if (renderer != null)
            {
                var c = renderer.color;
                c.a = 0f;
                renderer.color = c;
            }
        }
    }

    private void Update()
    {
        // ルーンのフェード効果
        foreach (var renderer in runeRenderers)
        {
            if (renderer != null)
            {
                Color current = renderer.color;
                Color target = new Color(current.r, current.g, current.b, targetAlpha);
                renderer.color = Color.Lerp(current, target, Time.deltaTime * colorChangeSpeed);
            }
        }
    }

    // 外部から呼び出してルーンを有効化する
    public void ActivateRunes()
    {
        isActivated = true;
        targetAlpha = 1f;
        Debug.Log("ルーンがアクティベートされました");
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("OnTriggerEnter2D 発動: " + other.name);

        if (gameCleared) return;

        if (!isActivated)
        {
            Debug.Log("まだルーンが有効化されていません");
            return;
        }

        if (other.CompareTag("Player"))
        {
            Debug.Log("プレイヤー接触。ルーン数: " + GameManager.Instance.runeCount);

            if (GameManager.Instance.runeCount >= 3)
            {
                GameClear();
            }
            else
            {
                Debug.Log("ルーンが足りません。必要数: 3, 現在: " + GameManager.Instance.runeCount);
            }
        }
    }

    private void GameClear()
    {
        gameCleared = true;
        Debug.Log("ゲームクリア！シーンを切り替えます。");

        try
        {
            SceneManager.LoadScene(gameClearSceneName);
        }
        catch (System.Exception e)
        {
            Debug.LogError("シーン遷移に失敗しました: " + e.Message);
        }
    }
}
