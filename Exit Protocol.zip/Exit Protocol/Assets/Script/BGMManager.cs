using UnityEngine;
using UnityEngine.Audio; // �� �K�{�I

public class BGMManager : MonoBehaviour
{
    public static BGMManager Instance;

    public AudioClip bgmClip;  // �Đ�����BGM
    public AudioMixerGroup outputMixerGroup; // �� �ǉ��FMixer�̏o�͐�
    private AudioSource audioSource;

    [Range(0f, 1f)]
    public float volume = 1.0f; // �f�t�H���g���ʁiInspector�Œ����\�j

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);

            audioSource = gameObject.AddComponent<AudioSource>();
            audioSource.loop = true;
            audioSource.playOnAwake = true;
            audioSource.volume = volume;

            // �� ������AudioMixerGroup��ݒ�
            if (outputMixerGroup != null)
            {
                audioSource.outputAudioMixerGroup = outputMixerGroup;
            }
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        PlayBGM();
    }

    public void PlayBGM()
    {
        if (bgmClip != null)
        {
            audioSource.clip = bgmClip;
            audioSource.volume = volume;
            audioSource.Play();
        }
    }

    public void StopBGM()
    {
        audioSource.Stop();
    }

    public void SetVolume(float newVolume)
    {
        volume = Mathf.Clamp01(newVolume);
        if (audioSource != null)
        {
            audioSource.volume = volume;
        }
    }

    public float GetVolume()
    {
        return volume;
    }
}
