using UnityEngine;

public class AttackHitbox : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Breakable"))
        {
            BreakableObject breakable = collision.GetComponent<BreakableObject>();
            if (breakable != null)
            {
                breakable.Break();
            }
        }
    }
}
