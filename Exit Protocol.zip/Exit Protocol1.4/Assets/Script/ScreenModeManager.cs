using UnityEngine;

public class ScreenModeManager : MonoBehaviour
{
    public enum ScreenMode
    {
        Windowed,
        Borderless,
        FullscreenExclusive
    }

    public void SetScreenMode(ScreenMode mode)
    {
        Resolution currentRes = Screen.currentResolution;

        switch (mode)
        {
            case ScreenMode.Windowed:
                Screen.SetResolution(1280, 720, FullScreenMode.Windowed);
                break;

            case ScreenMode.Borderless:
                Screen.SetResolution(currentRes.width, currentRes.height, FullScreenMode.FullScreenWindow);
                break;

            case ScreenMode.FullscreenExclusive:
                Screen.SetResolution(currentRes.width, currentRes.height, FullScreenMode.ExclusiveFullScreen);
                break;
        }

        Debug.Log("Switched to mode: " + mode.ToString());
    }

    // �T���v���F�L�[����Ő؂�ւ���
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F10))
            SetScreenMode(ScreenMode.Windowed);

        if (Input.GetKeyDown(KeyCode.F12))
            SetScreenMode(ScreenMode.FullscreenExclusive);
    }
}
