using UnityEngine.Audio;
using UnityEngine;

public class PushableObject : MonoBehaviour
{
    private Rigidbody2D rb;
    private AudioSource moveAudio;

    public float minMoveSpeed = 0.05f;
    public float seVolume = 1.0f;
    public float followSpeed = 5f;
    public float maxPullDistance = 0.8f; // ★追加！

    public bool isBeingPulled = false;
    public Transform pullTarget;

    public AudioMixerGroup mixerGroup;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        moveAudio = GetComponent<AudioSource>();

        if (mixerGroup != null)
        {
            moveAudio.outputAudioMixerGroup = mixerGroup;
        }

        moveAudio.volume = seVolume;
        moveAudio.loop = true;
        moveAudio.playOnAwake = false;
    }

    private void Update()
    {
        float speed = rb.linearVelocity.magnitude;

        if (speed > minMoveSpeed)
        {
            if (!moveAudio.isPlaying) moveAudio.Play();
        }
        else
        {
            if (moveAudio.isPlaying) moveAudio.Stop();
        }
    }

    private void FixedUpdate()
    {
        if (isBeingPulled && pullTarget != null)
        {
            float distance = Vector2.Distance(transform.position, pullTarget.position);

            if (distance <= maxPullDistance)
            {
                Vector2 direction = (pullTarget.position - transform.position).normalized;
                rb.linearVelocity = direction * followSpeed;
            }
            else
            {
                StopPull();
            }
        }
    }

    public void StartPull(Transform target)
    {
        isBeingPulled = true;
        pullTarget = target;
    }

    public void StopPull()
    {
        isBeingPulled = false;
        pullTarget = null;
        rb.linearVelocity = Vector2.zero;
    }
}
