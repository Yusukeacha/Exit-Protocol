using UnityEngine;

public class PortalWarp : MonoBehaviour
{
    [Header("���[�v���Transform")]
    public Transform warpTarget;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            Debug.Log("�|�[�^���ɐG��܂���");
            other.transform.position = warpTarget.position;
        }
    }
}
