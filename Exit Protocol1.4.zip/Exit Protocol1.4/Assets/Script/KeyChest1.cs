﻿using UnityEngine;
using UnityEngine.Audio;

public class KeyChest1 : MonoBehaviour, IInteractable
{
    [Header("Chest Settings")]
    public GameObject openedChestPrefab;
    public AudioClip openChestSE;
    public AudioMixerGroup mixerGroup;
    public float seVolume = 1.0f;
    public float openDelay = 0.1f;

    private bool hasOpened = false;

    public void Interact()
    {
        if (hasOpened) return;

        hasOpened = true;

        // ★ ルーンを手に入れる（GameManagerとチャットログ）
        GameManager.Instance.AddRune();
        int runeCount = GameManager.Instance.runeCount;
        ChatLogger.Instance?.Log($"ルーンを手に入れた！（{runeCount}/3）", "rune");

        // ★ 効果音を再生
        PlaySEWithMixer(openChestSE, transform.position, mixerGroup);

        // ★ 少し遅れて開いた宝箱に差し替え
        Invoke(nameof(ReplaceWithOpenedChest), openDelay);
    }

    private void ReplaceWithOpenedChest()
    {
        if (openedChestPrefab != null)
        {
            GameObject opened = Instantiate(openedChestPrefab, transform.position, transform.rotation);

            // 開いた宝箱にこのスクリプトが残っていたら消す（安全対策）
            var redundantScript = opened.GetComponent<KeyChest1>();
            if (redundantScript != null)
            {
                Destroy(redundantScript);
            }
        }

        Destroy(gameObject);
    }

    private void PlaySEWithMixer(AudioClip clip, Vector3 position, AudioMixerGroup mixer)
    {
        if (clip == null) return;

        GameObject seObject = new GameObject("TempChestSE");
        seObject.transform.position = position;

        AudioSource audioSource = seObject.AddComponent<AudioSource>();
        audioSource.clip = clip;
        audioSource.volume = seVolume;
        audioSource.spatialBlend = 0f;

        if (mixer != null)
        {
            audioSource.outputAudioMixerGroup = mixer;
        }

        audioSource.Play();
        Destroy(seObject, clip.length);
    }
}
