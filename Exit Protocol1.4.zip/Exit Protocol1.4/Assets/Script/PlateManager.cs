﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlateManager : MonoBehaviour
{
    public static PlateManager Instance { get; private set; }

    [SerializeField] private List<PressurePlate> plates;
    [SerializeField] private GameObject treasureChest;

    private int pressedCount = 0;
    private Coroutine resetCoroutine;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    public void RegisterPlatePress()
    {
        pressedCount++;

        if (pressedCount == 1 && resetCoroutine == null)
        {
            resetCoroutine = StartCoroutine(ResetTimer());
        }

        if (pressedCount >= plates.Count)
        {
            Debug.Log("全ての感圧板が押されました！宝箱オープンの準備ができました！");
            ChatLogger.Instance?.Log("すべての感圧板が押された！", "pressure_timer");

            if (resetCoroutine != null)
            {
                StopCoroutine(resetCoroutine);
                resetCoroutine = null;
            }
        }
    }

    public void RegisterPlateRelease()
    {
        pressedCount = Mathf.Max(0, pressedCount - 1);
    }

    private IEnumerator ResetTimer()
    {
        float timeLeft = 30f;

        ChatLogger.Instance?.Log("感圧板が押された。30秒以内に全て押そう", "pressure_timer");

        while (timeLeft > 0f)
        {
            yield return new WaitForSeconds(1f);
            timeLeft -= 1f;

            if ((int)timeLeft == 20 || (int)timeLeft == 10)
            {
                ChatLogger.Instance?.Log($"残り{(int)timeLeft}秒", "pressure_timer");
            }

            if (pressedCount >= plates.Count)
            {
                yield break;
            }
        }

        ChatLogger.Instance?.Log("時間切れ！リセットされました", "pressure_timer");
        Debug.Log("時間切れ！感圧板リセット！");
        ResetAllPlates();
        resetCoroutine = null;
    }

    private void ResetAllPlates()
    {
        foreach (var plate in plates)
        {
            plate.ForceReset();
        }
        pressedCount = 0;
    }

    public bool AreAllPlatesPressed() => pressedCount >= plates.Count;
}
