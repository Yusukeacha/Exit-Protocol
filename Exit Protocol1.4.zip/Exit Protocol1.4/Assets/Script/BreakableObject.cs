﻿using UnityEngine;
using UnityEngine.Audio;

public class BreakableObject : MonoBehaviour
{
    [Header("壊れた見た目")]
    public GameObject brokenVersionPrefab;

    [Header("ドロップアイテム")]
    public GameObject dropItemPrefab;

    [Header("サウンド設定")]
    public AudioClip breakSE;
    public AudioMixerGroup mixerGroup;
    [Range(0f, 1f)] public float seVolume = 1.0f;
    public float breakDelay = 0.1f;

    [Header("ルーンを含むか")]
    public bool containsRune = false;

    [Header("保存用ユニークID")]
    public string uniqueID;

    private bool isBreaking = false;

    private void Start()
    {
        // 壊れていたら自動削除（セーブデータに基づく）
        if (!string.IsNullOrEmpty(uniqueID) &&
            DestroyedObjectTracker.Instance != null &&
            DestroyedObjectTracker.Instance.IsDestroyed(uniqueID))
        {
            Destroy(gameObject);
        }
    }

    public void Break()
    {
        if (isBreaking) return;
        isBreaking = true;

        // セーブ用にIDを記録
        if (!string.IsNullOrEmpty(uniqueID) && DestroyedObjectTracker.Instance != null)
        {
            DestroyedObjectTracker.Instance.MarkDestroyed(uniqueID);
        }

        // 効果音を再生
        PlaySEWithMixer(breakSE, transform.position, mixerGroup);

        // 遅延して壊れる処理を呼び出し
        Invoke(nameof(HandleBreak), breakDelay);
    }

    private void HandleBreak()
    {
        // 壊れたオブジェクトの表示
        if (brokenVersionPrefab != null)
        {
            Instantiate(brokenVersionPrefab, transform.position, transform.rotation);
        }

        // ドロップアイテム
        if (dropItemPrefab != null)
        {
            Instantiate(dropItemPrefab, transform.position, Quaternion.identity);
        }

        // ルーンの取得
        if (containsRune)
        {
            GameManager.Instance?.AddRune();
            Debug.Log("壺やタルからルーンを手に入れた！");
        }

        Destroy(gameObject);
    }

    private void PlaySEWithMixer(AudioClip clip, Vector3 position, AudioMixerGroup mixer)
    {
        if (clip == null) return;

        GameObject seObject = new GameObject("TempBreakSE");
        seObject.transform.position = position;

        AudioSource audioSource = seObject.AddComponent<AudioSource>();
        audioSource.clip = clip;
        audioSource.volume = seVolume;
        audioSource.spatialBlend = 0f;

        if (mixer != null)
        {
            audioSource.outputAudioMixerGroup = mixer;
        }

        audioSource.Play();
        Destroy(seObject, clip.length);
    }
}
